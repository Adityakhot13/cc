
package org.spring_group;

import org.cloudbus.cloudsim.*;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;

import java.util.*;

public class CloudSimScheduling {

    public static void main(String[] args) {

        Log.printLine("Starting CloudSim Scheduling Simulation...");

        try {

            // Step 1: Initialize CloudSim
            int numUsers = 1;
            Calendar calendar = Calendar.getInstance();
            boolean traceFlag = false;

            CloudSim.init(numUsers, calendar, traceFlag);

            // Step 2: Create Datacenter
            Datacenter datacenter = createDatacenter("Datacenter_1");

            // Step 3: Create Broker
            DatacenterBroker broker = createBroker();

            int brokerId = broker.getId();

            // Step 4: Create Virtual Machines
            List<Vm> vmList = new ArrayList<>();

            int vmCount = 2;

            for (int i = 0; i < vmCount; i++) {

                Vm vm = new Vm(
                        i,
                        brokerId,
                        1000,
                        1,
                        1024,
                        1000,
                        10000,
                        "Xen",
                        new CloudletSchedulerTimeShared()
                );

                vmList.add(vm);
            }

            // Submit VMs to Broker
            broker.submitVmList(vmList);

            // Step 5: Create Cloudlets
            List<Cloudlet> cloudletList = new ArrayList<>();

            int cloudletCount = 6;

            UtilizationModel utilizationModel =
                    new UtilizationModelFull();

            for (int i = 0; i < cloudletCount; i++) {

                Cloudlet cloudlet = new Cloudlet(
                        i,
                        40000,
                        1,
                        300,
                        300,
                        utilizationModel,
                        utilizationModel,
                        utilizationModel
                );

                cloudlet.setUserId(brokerId);

                cloudletList.add(cloudlet);
            }

            // Submit Cloudlets to Broker
            broker.submitCloudletList(cloudletList);

            // Step 6: Round Robin Scheduling
            Log.printLine("\nApplying Round Robin Scheduling...\n");

            for (int i = 0; i < cloudletCount; i++) {

                int vmId = i % vmCount;

                broker.bindCloudletToVm(i, vmId);

                Log.printLine(
                        "Cloudlet " + i + " assigned to VM " + vmId
                );
            }

            // Step 7: Start Simulation
            CloudSim.startSimulation();

            // Step 8: Get Results
            List<Cloudlet> resultList =
                    broker.getCloudletReceivedList();

            CloudSim.stopSimulation();

            // Step 9: Display Results
            printCloudletList(resultList);

            Log.printLine("\nSimulation Completed Successfully!");

        } catch (Exception e) {

            e.printStackTrace();

        }
    }

    // Create Datacenter
    private static Datacenter createDatacenter(String name) {

        List<Host> hostList = new ArrayList<>();

        List<Pe> peList = new ArrayList<>();

        // Create CPU Processing Element
        peList.add(new Pe(
                0,
                new PeProvisionerSimple(10000)
        ));

        // Create Host
        Host host = new Host(
                0,
                new RamProvisionerSimple(8192),
                new BwProvisionerSimple(10000),
                1000000,
                peList,
                new VmSchedulerTimeShared(peList)
        );

        hostList.add(host);

        // Datacenter Characteristics
        String arch = "x86";
        String os = "Linux";
        String vmm = "Xen";

        double timeZone = 5.5;
        double cost = 3.0;
        double costPerMem = 0.05;
        double costPerStorage = 0.001;
        double costPerBw = 0.0;

        LinkedList<Storage> storageList = new LinkedList<>();

        DatacenterCharacteristics characteristics =
                new DatacenterCharacteristics(
                        arch,
                        os,
                        vmm,
                        hostList,
                        timeZone,
                        cost,
                        costPerMem,
                        costPerStorage,
                        costPerBw
                );

        Datacenter datacenter = null;

        try {

            datacenter = new Datacenter(
                    name,
                    characteristics,
                    new VmAllocationPolicySimple(hostList),
                    storageList,
                    0
            );

        } catch (Exception e) {

            e.printStackTrace();

        }

        return datacenter;
    }

    // Create Broker
    private static DatacenterBroker createBroker() {

        try {

            return new DatacenterBroker("Broker");

        } catch (Exception e) {

            e.printStackTrace();
            return null;
        }
    }

    // Display Cloudlet Results
    private static void printCloudletList(
            List<Cloudlet> list
    ) {

        String indent = "    ";

        Log.printLine("\n========== CLOUDLET RESULTS ==========");

        Log.printLine(
                "Cloudlet ID" + indent +
                        "Status" + indent +
                        "VM ID" + indent +
                        "Start Time" + indent +
                        "Finish Time"
        );

        for (Cloudlet cloudlet : list) {

            Log.print(indent + cloudlet.getCloudletId() + indent);

            if (cloudlet.getStatus() == Cloudlet.SUCCESS) {

                Log.print("SUCCESS");

                Log.printLine(
                        indent + cloudlet.getVmId() +
                                indent + cloudlet.getExecStartTime() +
                                indent + cloudlet.getFinishTime()
                );

            } else {

                Log.printLine("FAILED");
            }
        }
    }
}
